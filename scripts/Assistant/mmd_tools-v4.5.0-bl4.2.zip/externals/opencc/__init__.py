# Copyright (C) 2016 Yichen Huang (Eugene)
# Licensed under the Apache License, Version 2.0
##########################################################
# Author: Yichen Huang (Eugene)
# GitHub: https://github.com/yichen0831/opencc-python
# January, 2016
##########################################################

from .opencc import OpenCC

__all__ = ["OpenCC"]
